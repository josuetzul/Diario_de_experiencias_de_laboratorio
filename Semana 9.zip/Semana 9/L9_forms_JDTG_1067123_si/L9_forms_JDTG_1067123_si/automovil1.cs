﻿namespace L9_forms_JDTG_1067123_si
{
    internal class automovil
    {
    }
}