﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_JDTG_1067123
{
    class Circulo
    {

        private double radio, perimetro, volumen, area;


        //Constructor
        public Circulo(double elRadio)
        {
            radio = elRadio;
        }

        public void ObtenerPerimetro()
        {
            double perimetro = 2 * radio * Math.PI;
            Console.Write($"\nEl perímetro del círculo es: {perimetro}");
        }

        public void ObtenerArea()
        {
            double area = Math.PI * Math.Pow(radio, 2);
            Console.Write($"\nEl área del círculo es: {area}");
        }

        public void ObtenerVolumen()
        {
            double volumen = 4 * Math.PI * Math.Pow(radio, 3);
            volumen = volumen / 3;
            Console.Write($"\nEl volúmen de la esfera es: {volumen}");
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese el radio");
            double radio = Convert.ToDouble(Console.ReadLine());

            Circulo obj_circulo = new Circulo(radio);
            
            obj_circulo.ObtenerPerimetro();
            obj_circulo.ObtenerArea();
            obj_circulo.ObtenerVolumen();
            Console.ReadKey();
        }
    }
}
