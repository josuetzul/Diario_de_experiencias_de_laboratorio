﻿using System;
using System.ComponentModel.Design;
using System.Diagnostics.Tracing;

class program
{
    static void Main()
    {
        //Ejercicio 1

        Console.WriteLine("Ejercico 1");
        Console.WriteLine("Ingrese un número entero");
        int x = Convert.ToInt32(Console.ReadLine());

        if (x == 0)
        {
            Console.WriteLine("El número ingresado es cero");
        }
        else if (x > 0) 
        {
            Console.WriteLine("El número ingresado es positivo");
        }
        else if (x < 0)
        {
            Console.WriteLine("El número ingresado es negativo");
        }
        Console.WriteLine("El número que usted ingresó es: " + x);

        //Ejercicio 2

        Console.WriteLine("Ejercicio 2");
        Console.WriteLine("Ingrese un número de día");
        string numString = Console.ReadLine();
        int number1 = 0;
        int number2 = 0;

        //go to salida
        bool canConvert = int.TryParse(numString, out number1);
        if (canConvert == true)
        {
            if (number1 < 8 && number1 > 0)
            {
                Console.WriteLine("numero", number1);

                //salida
                Console.WriteLine("Vamos a ejecutar un switch");

                switch (number1)
                {
                    case 1:
                        Console.WriteLine("Lunes");
                        break;
                    case 2:
                        Console.WriteLine("Martes");
                        break;
                    case 3:
                        Console.WriteLine("Miércoles");
                        break;
                    case 4:
                        Console.WriteLine("Jueves");
                        break;
                    case 5:
                        Console.WriteLine("Viernes");
                        break;
                    case 6:
                        Console.WriteLine("Sábado");
                        break;
                    case 7:
                        Console.WriteLine("Domingo");
                        break;
                    default:
                        break;
                }
            } else
            {
                Console.WriteLine("Error: El número a ingresar debe estar contenido entre 1 y 7");
            }
        }
        else
        {
            Console.WriteLine("Ingrese un número");
        }

        
    }
}