﻿using System;

class Program
{
		static void Main (string[]args)
        {
            Console.WriteLine("Este es mi segundo programa");

            Console.WriteLine("Ingrese su nombre: ");
            string nombre = Console.ReadLine();

            Console.WriteLine("Ingrese su edad: ");
            string edad = Console.ReadLine();

            Console.WriteLine("Ingrese su carrera: ");
            string carrera = Console.ReadLine();

            Console.WriteLine("Ingrese su carné: ");
            string carnet = Console.ReadLine();

            Console.Write("Soy " + nombre);
            Console.Write(", tengo " + edad);
            Console.Write(" años y estudio la carrera de " + carrera);
            Console.Write(". Mi número de carné es: " + carnet);

            Console.ReadKey();

        }
}
