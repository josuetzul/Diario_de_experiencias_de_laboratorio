﻿using System;

public class Class1
{

		static void Main(string[] args)
		{
			Console.WriteLine("Ingrese su nombre: ");
			string nombre = Console.ReadLine();

			Console.WriteLine("Hola Mundo");
			Console.WriteLine("soy " + nombre);

			/*Diferencias*/

			Console.Write("Hola Mundo");
			Console.Write("soy Josue");
			Console.ReadKey();
		}
}