﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ejercico 1: operaciones aritméticas");
        Console.WriteLine("Ingrese un valor");
        int x = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese otro valor");
        int y = Convert.ToInt32(Console.ReadLine());

        int suma = x + y;
        Console.WriteLine("número 1 + número 2 = " + suma);
        int resta = x - y;
        Console.WriteLine("número 1 - número 2 = " + resta);
        int multiplicacion = x * y;
        Console.WriteLine("número 1 * número 2 = " + multiplicacion);
        double division = x / y;
        Console.WriteLine("número 1 / número 2 = " + division);
        int div = x / y;
        Console.WriteLine("número 1 // número 2 = " + div);
        int mod = x % y;
        Console.WriteLine("número 1 % número 2 =  " + mod);

        Console.WriteLine("Ejercicio 2: operaciones booleanas");

        if (x > y)
        {
            Console.WriteLine("El primer valor es más grande que el segundo");
        }
        else if (x < y)
        {
            Console.WriteLine("El segundo valor es más grande que el primero");
        }
        else if (x == y)
        {
            Console.WriteLine("El priemr valor y el segundo son iguales");
        }
    }
}